package com.example.bpm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;

import com.example.bpm.MainActivity.DoLogin;
import com.example.bpm.PathfinderAdd.AddPro;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



public class OkrDirSum extends Fragment {
	
	TextView year,objleft,dept,director;
	ConnectionClass connectionClass;
	
	public int user_id,dept_id;
	public String count,depart,dirFname,dirLname,dirFull;
	
	public OkrDirSum(){}
	
	
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
 
        View rootView = inflater.inflate(R.layout.okr_1, container, false);
        year = (TextView) rootView.findViewById(R.id.tvyear);
        objleft = (TextView) rootView.findViewById(R.id.tvobjleft);
        dept = (TextView) rootView.findViewById(R.id.tvdept);
        director = (TextView) rootView.findViewById(R.id.tvdir);
        
        
        
        connectionClass = new ConnectionClass();

        
        SharedPreferences pref = getActivity().getApplicationContext().getSharedPreferences("MyPref",Context. MODE_PRIVATE); 
        Editor editor = pref.edit();
        user_id = pref.getInt("userID", 0);
        dept_id = pref.getInt("deptID", 0); 

        DoFetch Fetch = new DoFetch();
        Fetch.execute("");
        
        
        
        return rootView;
    }
	
	@Override
	public void onResume(){
		
	    super.onResume();

        DoFetch Fetch = new DoFetch();
        Fetch.execute("");

	}
	
	
	public class DoFetch extends AsyncTask<String,String,String>
	 { 
	 String z = "";
	 Boolean isSuccess = false;
	 @Override
	 public void onPreExecute() {
		 
		 
	 }
	 @Override
	 public void onPostExecute(String r) {

	
		 if(isSuccess == true)
		 {
			 Calendar c = Calendar.getInstance(); 
		        int curryear = c.get(Calendar.YEAR);

		        year.setText(curryear);
		        objleft.setText(count);
		        dept.setText(depart);
		        director.setText(dirFull);
		 }
		
	 }
	 @Override
	 public String doInBackground(String... params) {
		 
	        
	
	 z = "Fetch Error";

	 {
	 try {
	 Connection con = connectionClass.CONN();
	 if (con == null) {
	 z = "Error in connection with SQL server";
	 } else {
		 
	 String query = "SELECT department_name from departments where dept_id = '"+dept_id+"'";
	 Statement stmt = con.createStatement();
	 ResultSet rs = stmt.executeQuery(query);
	 
	 String query2 = "SELECT COUNT(user_id) FROM directorobj where user_id = '"+user_id+"'";
	 Statement stmt2 = con.createStatement();
	 ResultSet rs2 = stmt.executeQuery(query2);
	 
	 String query3 = "SELECT user_fname,user_lname FROM users WHERE user_id IN (SELECT department_head FROM departments WHERE dept_id = '"+dept_id+"')";
	 Statement stmt3 = con.createStatement();
	 ResultSet rs3 = stmt.executeQuery(query3);
	 
	 if(rs.next()||rs2.next() ||rs3.next())
	 {
		 	
		 depart = rs.getString("department_name");
		 count = rs2.getString(1);
		 dirFname = rs3.getString("user_fname");
		 dirLname = rs3.getString("user_lname");
		 dirFull = String.valueOf(dirFname) + " " +String.valueOf(dirLname); 

		 	

		
	 isSuccess=true;
	 }
	 else
	 {
	 z = "Invalid Credentials";
	 isSuccess = false;
	 }
	 }
	 }
	 catch (Exception ex)
	 {
	 isSuccess = false;
	 z = "Error Somewhere";
	 Log.e("MYAPP", "exception", ex);
	 }
	 }
	 return z;
	 }
	 
	 
	 }
	
}
