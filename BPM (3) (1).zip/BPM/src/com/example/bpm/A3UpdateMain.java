package com.example.bpm;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class A3UpdateMain extends Activity{
	
	Button updateA3Now;
	ConnectionClass connectionClass;
	EditText projName2,projBackground2,projRecommendation2,projVision2,projIssues2;
	
	
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.update_a3_main);
		 
		 projName2 = (EditText) findViewById(R.id.edtProj2);
		 projBackground2 = (EditText) findViewById(R.id.edtBackground2);
		 projRecommendation2 = (EditText) findViewById(R.id.edtRecommendation2);
		 projVision2 = (EditText) findViewById(R.id.edtVision2);
		 projIssues2 = (EditText) findViewById(R.id.edtIssues2);
		 updateA3Now = (Button) findViewById(R.id.btnUpdateA3);

		 connectionClass = new ConnectionClass();
		 
		 Bundle a3bundle = getIntent().getExtras();
			
			
		String projName = a3bundle.getString("a3Name"); 
		String projBackground = a3bundle.getString("a3Background");
		String projRecommendation = a3bundle.getString("a3Recommendation");
		String projVision = a3bundle.getString("a3Vision");
		String projIssues = a3bundle.getString("a3Issues");
		
		projName2.setText(projName);
		projBackground2.setText(projBackground);
		projRecommendation2.setText(projRecommendation);
		projVision2.setText(projVision);
		projIssues2.setText(projIssues);
		
		updateA3Now.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
            	UpdateA3 updateA3Now = new UpdateA3();
            	updateA3Now.execute("");

            }
        });
			
		
	}
	
	public class UpdateA3 extends AsyncTask<String, String, String> {

		Bundle a3bundle = getIntent().getExtras();
		String projID = a3bundle.getString("a3ID"); 
        boolean isSuccess = false;
        String z = "";
        
        String projNameUp = projName2.getText().toString();
        String projBackgroundUp = projBackground2.getText().toString();
        String projRecommendationUp = projRecommendation2.getText().toString();
        String projVisionUp = projVision2.getText().toString();
        String projIssuesUp = projIssues2.getText().toString();
  
        
        @Override
        protected void onPreExecute() {

        }
        
        @Override
        protected void onPostExecute(String r) {
        	Toast.makeText(A3UpdateMain.this, r, Toast.LENGTH_SHORT).show();
            
        }
        @Override
        protected String doInBackground(String... params) {
        	if (projID.equals(""))
	            z = "Please fill all the fields";
            else {
            	
                try {
                    Connection con = connectionClass.CONN();
                    if (con == null) {
                        z = "Error in connection with SQL server";
                    } else {

						String query = "Update a3projects set proj_title='"+projNameUp+"',proj_background='"+projBackgroundUp+"'" +
                        ",proj_recommendation='"+projRecommendationUp+"',proj_issue='"+projIssuesUp+"',proj_vision='"+projVisionUp+"' WHERE proj_id ='"+projID+"'";

                        PreparedStatement preparedStatement = con.prepareStatement(query);
                        preparedStatement.executeUpdate();
                        z = "Updated Successfully";

                        isSuccess = true;
                    }
                } catch (Exception ex) {
                    isSuccess = false;
                    z = "Exceptions";
                    Log.e("MYAPP", "exception", ex);
                }
            }
            return z;
        }
    }
    

}
