package com.example.bpm;

import android.app.Application;

public class SetID extends Application{
	
	//private String name;
	private int ID;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

}
